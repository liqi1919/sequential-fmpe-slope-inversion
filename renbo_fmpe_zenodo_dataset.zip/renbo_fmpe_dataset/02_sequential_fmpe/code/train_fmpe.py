"""
Main training script for Sequential-FMPE slope parameter inversion.

Usage:
    python train_fmpe.py --config ../fmpe_config.json --output_dir ./output

Pipeline:
    1. Load prior distribution and FNO surrogate
    2. For each sequential round:
       a. Propose parameters from current proposal distribution
       b. Evaluate forward responses via FNO surrogate
       c. Accumulate (param, response) pairs
       d. Train/update flow matching network
       e. Generate posterior samples
       f. Update proposal distribution (GMM fit to posterior)
       g. Check convergence
    3. Save final posterior samples, model weights, and convergence report
"""
import argparse
import json
import os
import numpy as np
import torch
from torch.utils.data import DataLoader, TensorDataset

from flow_matching import VectorFieldNet, flow_matching_loss, sample_posterior
from sequential_sampler import SequentialSampler


def load_fno_surrogate(model_path, config_path):
    """Load trained FNO surrogate model for forward evaluation."""
    with open(config_path) as f:
        config = json.load(f)
    # In practice, load the actual FNO architecture and weights
    # Here we return a placeholder that should be replaced with real FNO inference
    print(f"Loading FNO surrogate from {model_path}")
    print(f"  Input dim: {config['input_dim']}, Output dim: {config['output_dim']}")
    return None  # Replace with actual loaded model


def prior_sampler(n):
    """Sample n parameter sets from prior distribution."""
    params = np.column_stack([
        np.random.normal(28.0, 5.04, n),       # c'_1
        np.random.normal(30.0, 4.50, n),       # phi'_1
        np.random.normal(-2.44, 0.45, n),      # log10 k_s1
        np.random.normal(30.0, 8.40, n),       # c'_2
        np.random.normal(33.0, 6.93, n),       # phi'_2
        np.random.normal(-3.15, 0.55, n),      # log10 k_s2
    ])
    return params


def evaluate_forward(params, fno_model=None):
    """
    Evaluate forward simulator for given parameters.
    Uses FNO surrogate if available; otherwise returns placeholder.
    In production, this calls the FNO model's forward method.
    """
    n = params.shape[0]
    # Placeholder: replace with actual FNO inference
    # Output should be (n, 171) = 57 days x 3 channels (flattened)
    return np.random.randn(n, 171) * 0.1  # Replace with real FNO output


def train_one_epoch(v_net, dataloader, optimizer, device):
    """Train flow matching network for one epoch."""
    v_net.train()
    total_loss = 0
    for params, responses in dataloader:
        params, responses = params.to(device), responses.to(device)
        optimizer.zero_grad()
        loss = flow_matching_loss(v_net, params, responses)
        loss.backward()
        torch.nn.utils.clip_grad_norm_(v_net.parameters(), 1.0)
        optimizer.step()
        total_loss += loss.item()
    return total_loss / len(dataloader)


def main():
    parser = argparse.ArgumentParser(description='Sequential-FMPE Training')
    parser.add_argument('--config', type=str, default='../fmpe_config.json')
    parser.add_argument('--fno_model', type=str, default='../../03_fno_surrogate/fno_model.pt')
    parser.add_argument('--fno_config', type=str, default='../../03_fno_surrogate/fno_config.json')
    parser.add_argument('--output_dir', type=str, default='./output')
    parser.add_argument('--device', type=str, default='cuda' if torch.cuda.is_available() else 'cpu')
    args = parser.parse_args()

    os.makedirs(args.output_dir, exist_ok=True)
    device = torch.device(args.device)
    print(f"Using device: {device}")

    # Load config
    with open(args.config) as f:
        config = json.load(f)

    # Load FNO surrogate
    fno_model = load_fno_surrogate(args.fno_model, args.fno_config)

    # Initialize flow matching network
    v_net = VectorFieldNet(
        d_m=config['input_dim'],
        d_y=config['context_dim'],
        hidden_dim=config['vector_field_net']['hidden_dims'][0],
        time_dim=config['vector_field_net']['time_embedding_dim'],
        context_dim=config['vector_field_net']['context_embedding_dim'],
        n_layers=len(config['vector_field_net']['hidden_dims']),
    ).to(device)

    optimizer = torch.optim.AdamW(
        v_net.parameters(),
        lr=config['training']['learning_rate'],
        weight_decay=config['training']['weight_decay'],
    )

    # Initialize sequential sampler
    sampler = SequentialSampler(
        prior_sampler=prior_sampler,
        n_rounds=config['sequential']['n_rounds'],
        samples_per_round=config['sequential']['samples_per_round'],
        n_gmm_components=config['sequential']['n_components'],
        convergence_threshold_pct=config['sequential']['convergence_threshold_pct'],
    )

    # Sequential training loop
    for round_idx in range(config['sequential']['n_rounds']):
        n_samples = config['sequential']['samples_per_round'][round_idx]
        print(f"\n=== Round {round_idx + 1}/{config['sequential']['n_rounds']} ===")
        print(f"  Proposing {n_samples} samples...")

        # Propose and evaluate
        params = sampler.propose(n_samples)
        responses = evaluate_forward(params, fno_model)

        # Train on accumulated data
        all_params, all_responses = sampler.get_accumulated_data() if round_idx > 0 else (np.empty((0, 6)), np.empty((0, 171)))
        all_params = np.vstack([all_params, params])
        all_responses = np.vstack([all_responses, responses])

        dataset = TensorDataset(
            torch.FloatTensor(all_params),
            torch.FloatTensor(all_responses)
        )
        dataloader = DataLoader(dataset, batch_size=config['training']['batch_size'], shuffle=True)

        print(f"  Training on {len(all_params)} accumulated samples...")
        for epoch in range(config['training']['n_epochs']):
            loss = train_one_epoch(v_net, dataloader, optimizer, device)
            if (epoch + 1) % 50 == 0:
                print(f"    Epoch {epoch+1}/{config['training']['n_epochs']}, Loss: {loss:.6f}")

        # Generate posterior samples
        print("  Generating posterior samples...")
        obs_context = torch.FloatTensor(np.loadtxt('../../01_field_monitoring/field_observations.csv',
                                                     delimiter=',', skiprows=1, usecols=range(3, 18))[:57].flatten()).unsqueeze(0)
        posterior_samples = sample_posterior(v_net, obs_context, n_samples=5000,
                                              d_m=config['input_dim'], n_steps=100, device=device)

        # Update sampler and check convergence
        converged = sampler.update(params, responses, posterior_samples)
        print(f"  Converged: {converged}")

        if converged and round_idx >= 2:
            print("  Convergence reached, stopping early.")
            break

    # Save final outputs
    print("\n=== Saving final outputs ===")
    np.save(f"{args.output_dir}/posterior_samples_final.npy", posterior_samples)
    torch.save(v_net.state_dict(), f"{args.output_dir}/fmpe_model_final.pt")

    # Save convergence report
    report = sampler.get_convergence_report()
    with open(f"{args.output_dir}/convergence_report.json", 'w') as f:
        json.dump(report, f, indent=2)

    print(f"  Posterior samples: {posterior_samples.shape}")
    print(f"  Posterior mean: {np.mean(posterior_samples, axis=0)}")
    print(f"  Posterior std: {np.std(posterior_samples, axis=0)}")
    print("Done!")


if __name__ == '__main__':
    main()
