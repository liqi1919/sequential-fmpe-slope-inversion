"""
Utility functions for Sequential-FMPE slope inversion.
"""
import numpy as np
from scipy import stats


def compute_posterior_statistics(posterior_samples, param_names=None):
    """
    Compute summary statistics for posterior samples.

    Args:
        posterior_samples: (N, d) array of posterior samples
        param_names: list of parameter names (optional)

    Returns:
        dict with mean, std, median, 2.5%, 97.5%, etc.
    """
    stats_dict = {
        'mean': np.mean(posterior_samples, axis=0),
        'std': np.std(posterior_samples, axis=0),
        'median': np.median(posterior_samples, axis=0),
        '2.5_percentile': np.percentile(posterior_samples, 2.5, axis=0),
        '97.5_percentile': np.percentile(posterior_samples, 97.5, axis=0),
    }
    if param_names:
        stats_dict['param_names'] = param_names
    return stats_dict


def compute_std_reduction(prior_std, posterior_std):
    """Compute standard deviation reduction percentage."""
    return (1 - posterior_std / prior_std) * 100


def simulation_based_calibration(v_net, prior_sampler, forward_fn, n_sbc=1000,
                                  d_m=6, n_posterior=500, device='cpu'):
    """
    Perform Simulation-Based Calibration (SBC).

    For each SBC run:
        1. Sample ground-truth parameters from prior
        2. Generate synthetic observation via forward model
        3. Run inference to get posterior samples
        4. Compute rank of ground-truth within posterior

    Uniform rank distribution indicates well-calibrated posterior.

    Reference: Talts et al. (2018), "Validating Bayesian Inference Algorithms with Simulation-Based Calibration"
    """
    import torch
    ranks = np.zeros((n_sbc, d_m))

    for i in range(n_sbc):
        # Sample ground truth
        theta_true = prior_sampler(1)  # (1, d_m)

        # Generate synthetic observation
        y_sim = forward_fn(theta_true)  # (1, d_y)

        # Get posterior samples
        y_tensor = torch.FloatTensor(y_sim).to(device)
        post_samples = sample_posterior(v_net, y_tensor, n_samples=n_posterior,
                                         d_m=d_m, device=device)

        # Compute rank
        for j in range(d_m):
            ranks[i, j] = np.sum(post_samples[:, j] < theta_true[0, j])

    return ranks


def posterior_predictive_check(posterior_samples, forward_fn, observations,
                                n_samples=100):
    """
    Perform Posterior Predictive Check (PPC).

    Feed posterior parameter samples back into forward model to generate
    predictive response ensemble, then compare with real observations.

    Args:
        posterior_samples: (N, d_m) posterior parameter samples
        forward_fn: forward model callable
        observations: (T, d_channels) observed time series
        n_samples: number of posterior samples to use for PPC

    Returns:
        predictive_ensemble: (n_samples, T, d_channels)
        discrepancy_metrics: dict with RMSE, coverage, etc.
    """
    idx = np.random.choice(len(posterior_samples), n_samples, replace=False)
    selected = posterior_samples[idx]

    predictive_ensemble = []
    for params in selected:
        pred = forward_fn(params.reshape(1, -1))
        predictive_ensemble.append(pred)
    predictive_ensemble = np.array(predictive_ensemble)

    # Compute discrepancy metrics
    median_pred = np.median(predictive_ensemble, axis=0)
    rmse = np.sqrt(np.mean((median_pred - observations) ** 2))

    # 95% predictive interval coverage
    lower = np.percentile(predictive_ensemble, 2.5, axis=0)
    upper = np.percentile(predictive_ensemble, 97.5, axis=0)
    coverage = np.mean((observations >= lower) & (observations <= upper))

    return {
        'predictive_ensemble': predictive_ensemble,
        'median_prediction': median_pred,
        'rmse': rmse,
        'coverage_95pct': coverage,
        'lower_2.5': lower,
        'upper_97.5': upper,
    }


def parameter_correlation_matrix(posterior_samples):
    """Compute pairwise parameter correlation matrix."""
    return np.corrcoef(posterior_samples.T)


def kl_divergence_gaussians(mu1, sigma1, mu2, sigma2):
    """Compute KL divergence between two univariate Gaussians."""
    return np.log(sigma2 / sigma1) + (sigma1**2 + (mu1 - mu2)**2) / (2 * sigma2**2) - 0.5
