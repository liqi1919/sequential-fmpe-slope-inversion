"""
Flow Matching core implementation for Sequential-FMPE.
Reference: Wildberger et al. (2023), "Flow Matching for Scalable Simulation-Based Inference", NeurIPS.
"""
import torch
import torch.nn as nn
import numpy as np


class SinusoidalTimeEmbedding(nn.Module):
    """Sinusoidal positional embedding for diffusion time t."""
    def __init__(self, dim):
        super().__init__()
        self.dim = dim

    def forward(self, t):
        device = t.device
        half_dim = self.dim // 2
        emb = np.log(10000) / (half_dim - 1)
        emb = torch.exp(torch.arange(half_dim, device=device) * -emb)
        emb = t[:, None] * emb[None, :]
        return torch.cat([emb.sin(), emb.cos()], dim=-1)


class VectorFieldNet(nn.Module):
    """
    Neural network v_phi(t, m, y) that regresses the conditional probability path vector field.
    Inputs:
        t: (B, 1) time in [0, 1]
        m: (B, d_m) parameter sample at time t
        y: (B, d_y) observation context
    Output:
        v: (B, d_m) predicted velocity field
    """
    def __init__(self, d_m=6, d_y=171, hidden_dim=256, time_dim=64, context_dim=128, n_layers=3):
        super().__init__()
        self.time_embed = SinusoidalTimeEmbedding(time_dim)
        self.context_proj = nn.Linear(d_y, context_dim)
        input_dim = d_m + time_dim + context_dim

        layers = []
        dims = [input_dim] + [hidden_dim] * n_layers + [d_m]
        for i in range(len(dims) - 1):
            layers.append(nn.Linear(dims[i], dims[i+1]))
            if i < len(dims) - 2:
                layers.append(nn.SiLU())
        self.net = nn.Sequential(*layers)

    def forward(self, t, m, y):
        t_emb = self.time_embed(t.squeeze(-1) if t.dim() > 1 else t)
        y_emb = self.context_proj(y)
        return self.net(torch.cat([m, t_emb, y_emb], dim=-1))


def flow_matching_loss(v_net, m1, y, sigma_min=1e-4):
    """
    Conditional flow matching training objective.
    L_FM = E_{t, m1, mt} || v_phi(t, mt, y) - m_dot_t ||^2

    Args:
        v_net: VectorFieldNet
        m1: (B, d_m) target samples from posterior
        y: (B, d_y) observations
        sigma_min: noise scale at t=0
    """
    B = m1.shape[0]
    device = m1.device
    t = torch.rand(B, 1, device=device)
    m0 = torch.randn_like(m1)

    # Straight-line interpolation: mt = (1-t)*m0 + t*m1
    mt = (1 - t) * m0 + t * m1
    # Target velocity for straight path
    m_dot = m1 - m0

    v_pred = v_net(t, mt, y)
    return ((v_pred - m_dot) ** 2).mean()


@torch.no_grad()
def sample_posterior(v_net, y, n_samples=1000, d_m=6, n_steps=100, device='cpu'):
    """
    Generate posterior samples via ODE integration:
        dm/dt = v_phi(t, m, y), m(0) ~ N(0, I), m(1) ~ p(m|y)

    Uses Euler method for simplicity; replace with dopri5 for higher accuracy.
    """
    m = torch.randn(n_samples, d_m, device=device)
    y_expand = y.expand(n_samples, -1)
    dt = 1.0 / n_steps

    for i in range(n_steps):
        t = torch.full((n_samples, 1), i * dt, device=device)
        v = v_net(t, m, y_expand)
        m = m + v * dt

    return m.cpu().numpy()
