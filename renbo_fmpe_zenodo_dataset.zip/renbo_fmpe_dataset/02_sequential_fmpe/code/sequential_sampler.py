"""
Sequential sampling for Sequential-FMPE.
Adaptively concentrates sampling effort within high-posterior-probability parameter domains.
"""
import numpy as np
from sklearn.mixture import GaussianMixture


class SequentialSampler:
    """
    Iterative proposal refinement for simulation-based inference.

    Each round:
        1. Sample parameters from current proposal distribution
        2. Run forward simulator (or surrogate) to get responses
        3. Train/update FMPE on accumulated (param, response) pairs
        4. Build new proposal from current posterior approximation (GMM)
        5. Check convergence based on posterior statistic relative change
    """

    def __init__(self, prior_sampler, n_rounds=6, samples_per_round=None,
                 n_gmm_components=5, convergence_threshold_pct=2.0):
        """
        Args:
            prior_sampler: callable(n) -> (n, d_m) samples from prior
            n_rounds: total number of sequential rounds
            samples_per_round: list of sample counts per round
            n_gmm_components: number of GMM components for proposal
            convergence_threshold_pct: max relative change (%) for convergence
        """
        self.prior_sampler = prior_sampler
        self.n_rounds = n_rounds
        self.samples_per_round = samples_per_round or [200, 200, 300, 300, 400, 400]
        self.n_gmm_components = n_gmm_components
        self.convergence_threshold = convergence_threshold_pct

        self.all_params = []
        self.all_responses = []
        self.posterior_means_history = []
        self.posterior_stds_history = []
        self.current_proposal = None
        self.converged = False

    def propose(self, n):
        """Sample n parameters from current proposal (or prior for round 1)."""
        if self.current_proposal is None:
            return self.prior_sampler(n)
        samples, _ = self.current_proposal.sample(n)
        return samples

    def update(self, new_params, new_responses, posterior_samples):
        """
        Update accumulated dataset and build new proposal from posterior.

        Args:
            new_params: (n, d_m) newly evaluated parameters
            new_responses: (n, d_y) corresponding simulator outputs
            posterior_samples: (N, d_m) current posterior approximation samples
        """
        self.all_params.append(new_params)
        self.all_responses.append(new_responses)

        # Track posterior statistics for convergence check
        mean = np.mean(posterior_samples, axis=0)
        std = np.std(posterior_samples, axis=0)
        self.posterior_means_history.append(mean)
        self.posterior_stds_history.append(std)

        # Build GMM proposal from posterior samples
        n_components = min(self.n_gmm_components, len(posterior_samples) // 10)
        if n_components >= 1:
            self.current_proposal = GaussianMixture(
                n_components=n_components, covariance_type='full', random_state=42
            )
            self.current_proposal.fit(posterior_samples)

        # Check convergence
        if len(self.posterior_means_history) >= 2:
            prev_mean = self.posterior_means_history[-2]
            curr_mean = self.posterior_means_history[-1]
            rel_change = np.max(np.abs(curr_mean - prev_mean) / (np.abs(prev_mean) + 1e-8)) * 100
            if rel_change < self.convergence_threshold:
                self.converged = True

        return self.converged

    def get_accumulated_data(self):
        """Return all accumulated (params, responses) for training."""
        return (np.vstack(self.all_params), np.vstack(self.all_responses))

    def get_convergence_report(self):
        """Return convergence statistics across rounds."""
        report = []
        for i in range(len(self.posterior_means_history)):
            if i == 0:
                rel_change = np.nan
            else:
                rel_change = np.max(
                    np.abs(self.posterior_means_history[i] - self.posterior_means_history[i-1])
                    / (np.abs(self.posterior_means_history[i-1]) + 1e-8)
                ) * 100
            report.append({
                'round': i + 1,
                'posterior_mean': self.posterior_means_history[i].tolist(),
                'posterior_std': self.posterior_stds_history[i].tolist(),
                'max_relative_change_pct': rel_change,
            })
        return report
